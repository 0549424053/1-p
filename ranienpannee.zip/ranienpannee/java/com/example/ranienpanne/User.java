package com.example.ranienpanne;





public class User {
    public String username, phone, type;

    public User() {}

    public User(String username, String phone, String type) {
        this.username = username;
        this.phone = phone;
        this.type = type;
    }
}
